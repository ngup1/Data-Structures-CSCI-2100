#include <iostream>
using namespace std;

int main() 
{ 
  float temperature;
  char unit;
  // TODO: Prompt user to enter temperature
  cout << "Enter the temperature: ";
  cin >> temperature;
  // TODO: Prompt user to enter unit (F for Fahrenheit, C for Celsius)
  cout << "Enter the unit (C or F): ";
  cin >> unit;
  // TODO: Convert temperature to the other unit
  if (unit == 'C' || unit == 'c'){
    // Convert Fahrenheit to Celsius
    // TODO: Implement the conversion formula here
    temperature = (temperature * 9/5) + 32;
    unit = 'F';
    cout << "The temperature in Fahrenheit is: " << temperature << " " << unit << endl;
  } else if (unit == 'F' || unit == 'f'){
    // Convert Celsius to Fahrenheit
    // TODO: Implement the conversion formula here
    temperature = (temperature - 32) * 5/9;
    unit = 'C';
    cout << "The temperature in Celsius is: " << temperature << " " << unit << endl;
  } else {
    // Handle invalid input
    // TODO: Display an error message
    cout << "Invalid unit entered. Please enter C or F." << endl;  
    }


}